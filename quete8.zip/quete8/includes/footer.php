<footer class="col-12 mt-3">
    <p class="text-center text-light"> &copy Thomas Brandt</p>
</footer>