<header class="container-fluide">
<div class="py-5 mb-4 text-white bg-dark">
    <div class="col-12">
      <h1 class="display-4">PHP Procédural</h1>
      <div class="border-top my-3"></div>
      <p class="lead my-3">Chaque difficulté rentrée doit être l'occasion d'un nouveau progrès</p>
    </div>
  </div>
</header>