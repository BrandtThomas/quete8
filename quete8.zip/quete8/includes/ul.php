<ul class = "list-unstyled col-12" method="GET">
                <li class="col-12 py-3 border-bottom border-light bg-secondary"><a href="index.php?debug" class="text-light">Débogage</a></li>
                <li class="col-12 py-3 border-bottom border-light bg-secondary"><a href="index.php?conc" class="text-light">Concaténation</a></li>
                <li class="col-12 py-3 border-bottom border-light bg-secondary"><a href="index.php?boucle" class="text-light">Boucle</a></li>
                <li class="col-12 py-3 border-bottom border-light bg-secondary"><a href="index.php?fonction" class="text-light">Fonction</a></li>
                <li class="col-12 py-3 border-bottom border-light bg-secondary"><a href="index.php?supprimer" class="text-light">Supprimer</a></li>
</ul>